package com.tailf.packages.ned.fortinetfortios;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;
import static java.util.Arrays.asList;
import java.io.IOException;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.log4j.Logger;
import com.tailf.maapi.MaapiCursor;

import java.lang.reflect.Method;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.InteractiveCallback;

import com.tailf.conf.Conf;
import com.tailf.conf.ConfBuf;
import com.tailf.conf.ConfKey;
import com.tailf.conf.ConfObject;
import com.tailf.conf.ConfPath;
import com.tailf.conf.ConfValue;
import com.tailf.conf.ConfXMLParam;
import com.tailf.conf.ConfXMLParamStart;
import com.tailf.conf.ConfXMLParamStop;
import com.tailf.conf.ConfXMLParamValue;
import com.tailf.dp.DpCallbackException;
import com.tailf.dp.DpTrans;
import com.tailf.dp.annotations.DataCallback;
import com.tailf.dp.annotations.TransCallback;
import com.tailf.dp.proto.DataCBType;
import com.tailf.dp.proto.TransCBType;
import com.tailf.maapi.Maapi;
import com.tailf.maapi.MaapiUserSessionFlag;
import com.tailf.navu.NavuContainer;
import com.tailf.navu.NavuContext;
import com.tailf.navu.NavuException;
import com.tailf.navu.NavuList;
import com.tailf.ncs.NcsMain;
import com.tailf.ncs.ResourceManager;
import com.tailf.ncs.annotations.Resource;
import com.tailf.ncs.annotations.ResourceType;
import com.tailf.ncs.annotations.Scope;
import com.tailf.ncs.ns.Ncs;
import com.tailf.ned.CliSession;
import com.tailf.ned.NedCapability;
import com.tailf.ned.NedCliBase;
import com.tailf.ned.NedCliBaseTemplate;
import com.tailf.ned.NedCmd;
import com.tailf.ned.NedException;
import com.tailf.ned.NedExpectResult;
import com.tailf.ned.NedMux;
import com.tailf.ned.NedTTL;
import com.tailf.ned.NedWorker;
import com.tailf.ned.NedWorker.TransactionIdMode;
import com.tailf.ned.TelnetSession;
import com.tailf.ned.SSHSession;
import com.tailf.ned.SSHConnection;
import com.tailf.ned.SSHSessionException;

/**
 * This class implements NED interface for fortinetfortios hardware
 *
 */

@SuppressWarnings("deprecation")
public class FortinetNedCli extends NedCliBaseTemplate {
    private String device_id;

    private SSHConnection connection;
    private CliSession session;

    private InetAddress ip;
    private int port;
    private String proto;  // ssh or telnet
    private String ruser;
    private String pass;
    private String secpass;
    private boolean trace;
    private int connectTimeout; // msec
    private int readTimeout;    // msec
    private int writeTimeout;   // msec
    private NedMux mux;
    private static Logger LOGGER  = Logger.getLogger(FortinetNedCli.class);
    private int vdom_enabled;
    NedCapability[]     capabilities;

    private String IDENTITY = "http://tail-f.com/ned/fortinet-fortios";
    private String MODULE   = "fortinet-fortios";

    private boolean isNetsimDevice = false;

    private static List<String> dynLinkInterfaces = new ArrayList<String>();
    private static List<String> dynVdomProps = new ArrayList<String>();

    @Resource(type=ResourceType.MAAPI, scope=Scope.INSTANCE)
    public  Maapi           mm;

    @Resource(type=ResourceType.MAAPI, scope=Scope.INSTANCE)
    private Maapi           maapi;

    private String date_string    = "2017-07-20";
    private String version_string = "4.0.19";
    private String platformModel;
    private String platformVersion;

    private boolean ignoreUnlicensedDevices = false;
    private int deviceChecksumDelay = 2000;
    private boolean licenseValidity = false;

    // List entries that should be ignored when modified/created (edit X)
    // or deleted (delete X). [0] = path, [1] = name of entry
    private String[][] static_list_entry =
    {
        { "/vdom/*/user group", "FSSO_Guest_Users" },
        { "/user group", "SSO_Guest_Users" },
        { "", "" }
    };
    // Remove configuration beginning with a given string and ending with exit
    private List<String> remConfig = new ArrayList<String>() {{
    	add("firewall multicast-address6");
    	add("application casi profile");
    	add("dnsfilter profile");
    	add("waf profile");
    }};

    private final static Pattern[] config_prompt, plw_prompt;

    // Virtual domain configuration: enable
    // FortiGate-VM64 (global) #
    // FortiGate-VM64 (global) #
    // FortiGate-VM64 (interface) #

    static {
        config_prompt = new Pattern[] {
            Pattern.compile(".*\\)[ ]#"),
            Pattern.compile("^[^#].* # ")
        };

        plw_prompt = new Pattern[] {
            Pattern.compile("You will be logged out for the operation to take"),
            Pattern.compile("Do you want to continue\\? \\(y/n\\)"),
            Pattern.compile("^[^#].* # ")
        };
    }

    private class keyboardInteractive implements InteractiveCallback {
        private String pass;
        public keyboardInteractive(String password) {
            this.pass = password;
        }
        public String[] replyToChallenge(String name, String instruction,
                                         int numPrompts, String[] prompt,
                                         boolean[] echo) throws Exception {
            LOGGER.info("replyToChallenge()");
            if (numPrompts == 0)
                return new String[] {};
            if (numPrompts != 1) {
                throw new Exception("giving up");
            }
            return new String[] { pass };
        }
    }

    public FortinetNedCli() {
    }

    public FortinetNedCli(String device_id,
               InetAddress ip,
               int port,
               String proto,  // ssh or telnet
               String ruser,
               String pass,
               String secpass,
               boolean trace,
               int connectTimeout, // msec
               int readTimeout,    // msec
               int writeTimeout,   // msec
               NedMux mux,
               NedWorker worker) {

        LOGGER.info("FortinetNedCli(ip="+ip+", port="+port+")");

        this.device_id = device_id;
        this.ip = ip;
        this.port = port;
        this.proto = proto;
        this.ruser = ruser;
        this.pass = pass;
        this.secpass = secpass;
        this.trace = trace;
        this.connectTimeout = connectTimeout;
        this.readTimeout = readTimeout;
        this.writeTimeout = writeTimeout;
        this.mux = mux;

        try {
            ResourceManager.registerResources(this);
        } catch (Exception e) {
            LOGGER.error("Error injecting Resources", e);
        }

    }

    private boolean connect(NedWorker worker, NedMux mux) {
        LOGGER.info("connect() - connecting to "+ip+":"+port);

        try {
            try {
                if (proto.equals("ssh")) {
                    trace(worker, "SSH connecting to host: "+
                            ip.getHostAddress()+":"+port, "out");

                    connection = new SSHConnection(worker);
                    connection.connect(null, 0, connectTimeout);

                    String authMethods[] = connection.
                            getRemainingAuthMethods(ruser);
                    boolean hasPassword=false;
                    boolean hasKeyboardInteractive=false;

                    for(int i=0 ; i < authMethods.length ; i++) {
                        if (authMethods[i].equals("password"))
                            hasPassword = true;
                        else if (authMethods[i].equals("keyboard-interactive"))
                            hasKeyboardInteractive = true;
                    }

                    boolean isAuthenticated = false;
                    if (hasPassword) {
                        isAuthenticated = connection.
                                authenticateWithPassword(ruser, pass);
                    } else if (hasKeyboardInteractive) {
                        InteractiveCallback cb = new keyboardInteractive(pass);
                        isAuthenticated = connection.
                                authenticateWithKeyboardInteractive(ruser, cb);
                    }

                    if (!isAuthenticated) {
                        trace(worker, "SSH autentication failed", "out");
                        LOGGER.error("auth connect failed ");
                        worker.connectError(NedWorker.CONNECT_BADPASS,
                                "Auth failed");
                        return false;
                    }

                    trace(worker, "SSH initializing session", "out");

                    session = new SSHSession(connection, readTimeout,
                            worker, this, 4096, 100);
                }
                else {
                    // Telnet
                    TelnetSession tsession;
                    NedExpectResult res;

                    trace(worker, "TELNET connecting to host: "+
                          ip.getHostAddress()+":"+port, "out");
                    if (trace)
                        tsession =
                            new TelnetSession(worker, ruser,
                                              readTimeout, worker, this);
                    else
                        tsession =
                            new TelnetSession(worker, ruser,
                                              readTimeout, null, this);

                    tsession.setScreenSize(4096, 65000);
                    trace(worker, "TELNET looking for login prompt", "out");
                    session = tsession;
                    try {
                        res = session.expect(new String[] {"[Ll]ogin:",
                                                           "[Nn]ame:",
                                                           "[Pp]assword:"});
                    } catch (Throwable e) {
                        throw new NedException(NedWorker.CONNECT_BADAUTH,
                                               "No login prompt");
                    }
                    if (res.getHit() < 2) {
                        session.println(ruser);
                        trace(worker, "TELNET looking for password prompt",
                                      "out");
                        try {
                            session.expect(new String[] {"[Pp]assword:"});
                        } catch (Throwable e) {
                            throw new NedException(NedWorker.CONNECT_BADAUTH,
                                                   "No password prompt");
                        }
                    }
                    session.println(pass);
                }
            }
            catch (Exception e) {
                LOGGER.error("connect failed ",  e);
                worker.connectError(NedWorker.CONNECT_CONNECTION_REFUSED,
                                    e.getMessage());
                return false;
            }
        }

        catch (NedException e) {
            LOGGER.error("connect response failed ",  e);
            return false;
        }

        try {
            NedExpectResult res;

            res = session.expect(new String[] {".*>", ".*#"}, worker);
            if (res.getHit() == 0) {
                LOGGER.error("Bad login prompt");
            }
            // LOG NCS and NED version & date
            trace(worker, "NCS VERSION: "+Conf.PROTOVSN+" "
                  +String.format("%x", Conf.LIBVSN),"out");

            trace(worker, "NED VERSION: fortinet-fortios "
                  +version_string+" "+date_string, "out");

            /* Get system status in order to see if VDOM enabled/disabled */
            //System.err.println(" > get system status");
            session.print("get system status\n");
            String version = session.expect(".*#", worker);

            if (version.indexOf("NETSIM") >= 0) {
                isNetsimDevice = true;
                session.println("paginate false");
                session.expect(".*#");
                session.println("config");
                session.expect(".*#");
            }

            /* Set VDOM mode, 1 = enable */
            if (version.indexOf("Virtual domain configuration: enable") >= 0) {
                LOGGER.info("VDOM enabled");
                trace(worker, "VDOM enabled", "out");
                vdom_enabled = 1;
            } else {
                LOGGER.info("VDOM disabled");
                trace(worker, "VDOM disabled", "out");
                vdom_enabled = 0;
                IDENTITY = "http://tail-f.com/ned/fortinet-fortios-non-vdom";
                MODULE =   "fortinet-fortios-non-vdom";
            }
            if (version.indexOf("License Status: Valid") >= 0) {
                licenseValidity = true;
            }
            if (isNetsimDevice == false) {
                readNedSettings();

                if (!ignoreUnlicensedDevices || licenseValidity) {
                    // Turn off paginate
                    if (vdom_enabled == 1) {
                        session.print("config global\n");
                        session.expect("config global", worker);
                        session.expect(".*\\(global\\)[ ]#", worker);
                    }
                    try {
                        enterSystem(worker, "console");
                        //System.err.println(" > set output standard");
                        session.print("set output standard\n");
                        session.expect(".*#", worker);
                        moveToTopConfig();
                    }
                    catch (Exception e) {
                        LOGGER.error("Invalid device license!",  e);
                        worker.error(NedCmd.CONNECT_CLI, "Invalid device license!");
                        return false;
                    }
                }
            }

            LOGGER.info("Disabled paginate (output=standard)");

            /* Verify supported hardware */
            if ( (version.toLowerCase().indexOf("fortigate-200b") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-3240c") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-vm64") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-1000c") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-300c") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-3140b") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-1000d") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-3040b") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-100d") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-200d") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-500d") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-800c") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-1500d") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-200a") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-310b") >= 0) ||
                 (version.toLowerCase().indexOf("fortigate-3100d") >= 0) ||
                 (version.toLowerCase().indexOf("fortios-vm64") >= 0)) {
                // found
                LOGGER.info("Logged in");

                capabilities =
                        new NedCapability[]{
                        new NedCapability(
                                       "",
                                       IDENTITY,
                                       MODULE,
                                       "",
                                       date_string,
                                       ""),
                        new NedCapability(
                                       "urn:ietf:params:netconf:capability:" +
                                       "with-defaults:1.0?basic-mode=trim",
                                       "urn:ietf:params:netconf:capability:" +
                                       "with-defaults:1.0",
                                       "",
                                       "",
                                       "",
                                       "")
                };
                try {
                    setConnectionData(capabilities,
                                      null,
                                      true,
                                      TransactionIdMode.UNIQUE_STRING);
                    if (isNetsimDevice) {
                        platformModel = "NETSIM";
                        platformVersion = "NETSIM";
                    }
                    else {
                        try {
                            int start = version.indexOf("Version: ") + 9;
                            int end = version.indexOf(",", start);
                            String versionModel = version.substring(start, end);
                            platformModel = versionModel.split(" ")[0].toLowerCase();
                            platformVersion = versionModel.split(" ")[1];
                        }
                        catch (Exception e) {
                            platformModel = "";
                            platformVersion = "";
                        }
                    }
                    LOGGER.info("Found platform model:   " +platformModel);
                    LOGGER.info("Found platform version: " +platformVersion);

                    /*
                     * On NSO 4.0 and later, do register device model and
                     * os version.
                     */
                    if (Conf.LIBVSN >= 0x6000000) {
                        ConfXMLParam[] platformData =
                            new ConfXMLParam[] {
                                new ConfXMLParamStart("ncs", "platform"),
                                new ConfXMLParamValue("ncs", "name",
                                        new ConfBuf("Fortigate")),
                                new ConfXMLParamValue("ncs", "version",
                                        new ConfBuf(platformVersion)),
                                new ConfXMLParamValue("ncs", "model",
                                        new ConfBuf(platformModel)),
                                new ConfXMLParamStop("ncs", "platform")
                        };

                        Method method = this.getClass().
                            getMethod("setPlatformData",
                                      new Class[]{ConfXMLParam[].class});
                        method.invoke(this, new Object[]{platformData});
                    }

                }
                catch (Exception e) {
                    worker.error(NedCmd.CONNECT_CLI, e.getMessage());
                }
                return true;
            } else {
                LOGGER.error("Failed to log in, unknown device");
                worker.error(NedCmd.CONNECT_CLI, "unknown device");
            }
        }
        catch (SSHSessionException e) {
            worker.error(NedCmd.CONNECT_CLI, e.getMessage());
        }
        catch (IOException e) {
            worker.error(NedCmd.CONNECT_CLI, e.getMessage());
        }
        catch (Exception e) {
            worker.error(NedCmd.CONNECT_CLI, e.getMessage());
        }
        return false;
    }

    private void readNedSettings()
            throws Exception {

        ArrayList<String> paths = new ArrayList<String>();
        try {
            maapi.setUserSession(1);
            int th = maapi.startTrans(Conf.DB_RUNNING, Conf.MODE_READ);

            paths.add("/ncs:devices/ncs:global-settings");
            // Get device profile
            try {
                String p = "/ncs:devices/device{"+device_id+"}/device-profile";
                if (mm.exists(th, p)) {
                    String deviceProfile = ConfValue.getStringByValue(p, maapi.getElem(th, p));
                    paths.add("/ncs:devices/ncs:profiles/profile{" + deviceProfile + "}");
                }
            } catch (Exception e) {

            }

            paths.add("/ncs:devices/device{" + device_id +"}");
            for (String path : paths) {
                path += "/ncs:ned-settings/fortinet-fortios-meta:fortinet-fortios-connection/";
                try {
                    if (mm.exists(th, path)) {
                        ConfValue val = maapi.safeGetElem(th, path + "ignore-unlicensed-devices");
                        if (val != null) {
                            ignoreUnlicensedDevices = val.toString().equals("true") ? true : false;
                        }
                        val = maapi.safeGetElem(th, path + "device-checksum-delay");
                        if (val != null) {
                            deviceChecksumDelay = Integer.parseInt(val.toString());
                        }

                    }
                }
                catch (Exception e) {
                }
            }
            maapi.finishTrans(th);
        }
        catch (Exception e) {
        }
    }

    public void reconnect(NedWorker worker) {
    }

    public String device_id() {
        return device_id;
    }

    // should return "cli" or "generic"
    public String type() {
        return "cli";
    }

    // Which Yang modules are covered by the class
    public String [] modules() {
        return new String[] { MODULE };
    }

    // Which identity is implemented by the class
    public String identity() {
        return "fortinet-fortios-id:fortinet-fortios";
    }

    private void moveToTopConfig()
        throws IOException, SSHSessionException {

        //System.err.println("moveToTopConfig()");

        if (isNetsimDevice == false) {
            while (true)
            {
                session.print("?");
                String menu = session.expect(".*#");
                if (menu.toLowerCase().indexOf("end and save last config") < 0)
                    return;
                //System.err.println(" > end");
                session.print("end\n");
                session.expect(".*#");
            }
        }
        else {
            session.println("top");
            session.expect(".*#");
        }
    }

    private void maapiStartUserSession(Maapi m) {
        // if the user session doesn't exist, start it
        try {
            m.startUserSession("system",
                    InetAddress.getByName("localhost"),
                    "system",
                    new String[] { "system" },
                    MaapiUserSessionFlag.PROTO_TCP);
        }
        catch (Exception e) {
        }
    }

    private boolean isStaticListEntry(String path, String cmd) {
        for (int n = 0; static_list_entry[n][0] != ""; n++)
            if (path.equals(static_list_entry[n][0])
                && static_list_entry[n][1].equals(cmd))
                return true;
        return false;
    }

    private boolean isDynamicInterface(NedWorker worker, String path,
            String cmd, String dir) throws Exception, NavuException {
        if (path.contains("system interface")) {
            int th = dir.equals("FROM") ? worker.getFromTransactionId() :
                                          worker.getToTransactionId();
            maapi.attach(th, 0, worker.getUsid());
            try {
                String prefixPath = "/ncs:devices/device{" + device_id +
                                    "}/config/" + MODULE + ":";
                if (vdom_enabled == 1) {
                    String vdomPath = prefixPath + "vdom/vdom-list";
                    MaapiCursor c = maapi.newCursor(th, vdomPath);
                    ConfKey x = maapi.getNext(c);
                    while (x != null) {
                        if (maapi.exists(th, vdomPath +
                            "{%x}/vpn/ipsec/phase1-interface/"+
                            "phase1-interface-list{%s}", x, cmd)) {
                            return true;
                        }
                        x = maapi.getNext(c);
                    }
                }
                else {
                    if (maapi.exists(th, prefixPath +
                        "vpn/ipsec/phase1-interface/phase1-interface-list{%s}",
                        cmd)) {
                        return true;
                    }
                }
            }
            finally {
                maapi.detach(th);
            }
        }
        return false;
    }


    private boolean isDynamicVdomLinkInterface(String path, String cmd)
            throws Exception, NavuException {
        if (path.equals("/global/system interface")) {
            maapiStartUserSession(maapi);
            int th = maapi.startTrans(Conf.DB_RUNNING,
                    Conf.MODE_READ);

            NavuContainer vdomLink;
            try {
                NavuContext context = new NavuContext(maapi, th);
                if (vdom_enabled == 1) {
                    vdomLink = new NavuContainer(context)
                    .container(Ncs.hash)
                    .container(Ncs._devices_)
                    .list(Ncs._device_)
                    .elem(new ConfKey(new ConfBuf(device_id)))
                    .container(Ncs._config_)
                    .container("fortinet-fortios", "global")
                    .container("fortinet-fortios", "system")
                    .container("fortinet-fortios", "vdom-link")
                    .list("fortinet-fortios", "vdom-link-list")
                    .elem(cmd.substring(0, cmd.length() - 1));
                }
                else {
                    vdomLink = new NavuContainer(context)
                    .container(Ncs.hash)
                    .container(Ncs._devices_)
                    .list(Ncs._device_)
                    .elem(new ConfKey(new ConfBuf(device_id)))
                    .container(Ncs._config_)
                    .container("fortinet-fortios-non-vdom", "system")
                    .container("fortinet-fortios-non-vdom", "vdom-link")
                    .list("fortinet-fortios-non-vdom", "vdom-link-list")
                    .elem(cmd.substring(0, cmd.length() - 1));
                }
            }
            finally {
                maapi.finishTrans(th);
            }
            if (vdomLink != null) return true;

            for (String interf:dynLinkInterfaces) {
                if (cmd.equals(interf)) return true;
            }
        }
        return false;
    }

    private boolean isDynamicVdomProperty(String path, String cmd)
            throws Exception, NavuException {
        if (path.startsWith("/global/system vdom-property")) {
            maapiStartUserSession(maapi);
            int th = maapi.startTrans(Conf.DB_RUNNING,
                    Conf.MODE_READ);
            try {
                NavuContext context = new NavuContext(maapi, th);
                NavuContainer vdom = new NavuContainer(context)
                    .container(Ncs.hash)
                    .container(Ncs._devices_)
                    .list(Ncs._device_)
                    .elem(new ConfKey(new ConfBuf(device_id)))
                    .container(Ncs._config_)
                    .container("fortinet-fortios", "vdom")
                    .list("fortinet-fortios", "vdom-list")
                    .elem(cmd);

                if (vdom != null) return true;

                for (String dynVdomProp:dynVdomProps) {
                    if (cmd.equals(dynVdomProp)) return true;
                }
            }
            finally {
                maapi.finishTrans(th);
            }
        }
        return false;
    }

    private boolean removeIdentityBasedPolicy(int index, String[] lines) {
        if ( (index > 0) &&
            (lines[index-1].indexOf("config identity-based-policy") >= 0) &&
            (lines[index].indexOf("delete") >= 0) ) {
            return true;
        }
        return false;
    }

    private void handleIdentityBasedPolicyRemoval(NedWorker worker,
            int cmd, String path, String orgline, int index, String[] lines)
            throws Exception, NedException, IOException {
        /*
         * As per Fortigate weird behaviour: if an 'identity-based-policy'
         * entry is configured, at least one entry must exist until its
         * parent 'policy' deletion. So during 'identity-based-policy' entries
         * deletion process, if the last entry is trying to be deleted it means
         * that its parent policy is going to be deleted as well. So allow its
         * deletion but emporarly create a dummy 'identity-based-policy' entry
         * which will be deleted anyway, when its parent policy will be deleted.
         */

        for (int j = index - 1; j >= 0; j--) {
            if ( (lines[j].indexOf("config firewall policy") >= 0) &&
                (lines[j+1].indexOf("edit") >= 0)) {
                String policy_id = lines[j+1].substring(lines[j+1].
                        indexOf("edit")+5);

                ConfPath identity_policy_path = null;
                if (vdom_enabled == 1) {
                    for (int k = j - 1; k >= 0; k--) {
                        if ((lines[k].indexOf("config vdom") >= 0) &&
                                (lines[k+1].indexOf("edit") >= 0)) {
                            String vdom_id = lines[k+1].substring(lines[k+1].
                                      indexOf("edit")+5);

                            identity_policy_path = new ConfPath(
                                    "/devices/device{%s}/config/" + MODULE +
                                    ":vdom/" + "vdom-list{%s}/firewall/policy/"+
                                    "policy-list{%s}/identity-based-policy/"+
                                    "policy-list",
                                    device_id, vdom_id, policy_id);
                            break;
                        }
                    }
                }
                else {
                    identity_policy_path = new ConfPath(
                            "/devices/device{%s}/config/" + MODULE +
                            ":firewall/policy/"+
                            "policy-list{%s}/identity-based-policy/"+
                            "policy-list",
                            device_id, policy_id);
                }

                maapiStartUserSession(maapi);
                int th = maapi.startTrans(Conf.DB_RUNNING,
                        Conf.MODE_READ);
                try {
                    if (maapi.getNumberOfInstances(th,
                            identity_policy_path) == 1) {

                        print_line_wait(worker, cmd, path, orgline,
                                "edit 999999", 0);
                        print_line_wait(worker, cmd, path, orgline,
                                "set schedule always", 0);
                        print_line_wait(worker, cmd, path, orgline,
                                "set service ALL", 0);
                        print_line_wait(worker, cmd, path, orgline,
                                "set sslvpn-portal web-access", 0);
                        print_line_wait(worker, cmd, path, orgline,
                                "next", 0);
                    }
                }
                finally {
                    maapi.finishTrans(th);
                }
            }
        }
    }

    private String stringDequote(String aText) {
        if (aText.indexOf("\"") != 0)
            return aText;

        aText = aText.substring(1,aText.length()-1);

        StringBuilder result = new StringBuilder();
        StringCharacterIterator iterator =
            new StringCharacterIterator(aText);
        char c1 = iterator.current();

        while (c1 != CharacterIterator.DONE ) {
            if (c1 == '\\') {
                char c2 = iterator.next();
                if (c2 == CharacterIterator.DONE )
                    result.append(c1);
                else if (c2 == 'b')
                    result.append('\b');
                else if (c2 == 'n')
                    result.append('\n');
                else if (c2 == 'r')
                    result.append('\r');
                else if (c2 == 'v')
                    result.append((char) 11); // \v
                else if (c2 == 'f')
                    result.append('\f');
                else if (c2 == 't')
                    result.append('\t');
                else if (c2 == 'e')
                    result.append((char) 27); // \e
                else {
                    result.append(c2);
                }
            }
            else {
                // The char is not a special one, add it to the result as is
                result.append(c1);
            }
            c1 = iterator.next();
        }
        return result.toString();
    }

    private String stringQuote(String aText) {
        StringBuilder result = new StringBuilder();
        StringCharacterIterator iterator =
            new StringCharacterIterator(aText);
        char character =  iterator.current();
        result.append("\"");
        while (character != CharacterIterator.DONE ){
            if (character == '"')
                result.append("\\\"");
            else if (character == '\\')
                result.append("\\\\");
            else if (character == '\b')
                result.append("\\b");
            else if (character == '\n')
                result.append("\\n");
            else if (character == '\r')
                result.append("\\r");
            else if (character == (char) 11) // \v
                result.append("\\v");
            else if (character == '\f')
                result.append("'\f");
            else if (character == '\t')
                result.append("\\t");
            else if (character == (char) 27) // \e
                result.append("\\e");
            else
                // The char is not a special one, add it to the result as is
                result.append(character);
            character = iterator.next();
        }
        result.append("\"");
        return result.toString();
    }

    private String getDeviceConfig(NedWorker worker)
    		throws IOException, SSHSessionException, NedException {
    	String res;
    	String rest;

    	moveToTopConfig();

    	session.println("show");
    	session.expect("show", worker);
    	rest = session.expect("^[^#].* # ", worker);

    	// Process the config to quote all the strings (single or multiple line)
    	Pattern comments = Pattern.compile("set (comments|comment|buffer|"
    			+ "description|private-key|certificate)");
    	Matcher match = comments.matcher(rest);
    	while (match.find()) {
    		int    start = match.start();
    		int    end   = match.end();
    		String item  = rest.substring(start, end);
    		end          = rest.indexOf("\"", start+2+item.length());
    		if (item.equals("buffer")) {
    			end = rest.indexOf("\"\r", start+2+item.length());
    		}

    		if (end >= 0) {
    			String elem = rest.substring(
    					start + 2 + item.length(), end);
    			elem = elem.replaceAll("\r\n", "\n");
    			rest = rest.substring(0, start + 1 + item.length()) +
    					stringQuote(elem) +
    					rest.substring(end+1);
    		}
    	}

    	// Remove some parts of the config
    	Pattern removedContent = Pattern.compile(
    			"\\s*set\\s+(private-key|certificate)");
    	Matcher rem            = removedContent.matcher(rest);
    	while (rem.find()) {
    		int start = rem.start();
    		int end   = rest.indexOf("\n", start+4);

    		if (end > start+1) {
    			rest = rest.substring(0, start) + rest.substring(end);
    		}
    		rem = removedContent.matcher(rest);
    	}

    	// Leave 'global' dir
    	res = rest + "\nexit\n";
    	return res;
    }


    private String getConfig(NedWorker worker)
        throws IOException, SSHSessionException, NedException {

        // adding the device model to the hidden configuration
        String res = "version " + platformVersion + "\n";
        LOGGER.info("getConfig()");

        if (isNetsimDevice == false) {
            res += getDeviceConfig(worker);
        }
        else {
            session.println("do show running-config");
            session.expect("do show running-config", worker);
            res = session.expect(".*#", worker);
            res = res.replaceAll("!", "exit");
            res = res.replaceAll("edit (.*)\r", "edit \"$1\"\r");
        }
        // Convert to IOS-style for NCS parsing
        // Replace "(\n|\r| )config " with ""
        res = res.replaceAll("(\n|\r| )config ", "$1");
        // Replace "edit " with ""
        res = res.replaceAll("edit ", "");
        // Replace "unset " with "no "
        res = res.replaceAll("unset ", "no ");
        // Replace "set " with ""
        res = res.replaceAll("([ ]+)set ", "$1");
        // Replace "next\r" with "exit\r"
        res = res.replaceAll("([ ]+)next([ ]*)\r\nend", "$1exit\r\nexit");

        res = res.replaceAll("([!-]*)next([!-]*)\r", "$1exit$2\r");
        // Replace "end\r" with "exit\r"
        res = res.replaceAll("([ ]+)end\r", "$1exit\r");

        res = res.replaceAll("end\r", "\r");
        // filter out uuid and snmp-index
        res = res.replaceAll("(\n|\r| )*(uuid|snmp-index) [^\r\n]*(\n|\r)",
                              "$3");
        // remove encoded passwords
        res = res.replaceAll("\\s+password\\s+ENC\\s.*", "");
        // Remove config starting with a given string and ending with exit
        Iterator<String>it = remConfig.iterator();
        while (it.hasNext()) {
        	res = res.replaceAll(it.next() + "(\r|\n|\n\r|\r\n)([ ]+(.*)" +
                  "(\r|\n|\n\r|\r\n))*exit", "");
        }

        return res;
    }

    private void print_line_wait(NedWorker worker, int cmd,
                                 String path, String orgline, String line,
                                 int retrying)
        throws NedException, IOException, SSHSessionException, ApplyException {
        NedExpectResult res = null;
        String reply;

        LOGGER.info("Sending("+path+") "+line);

        // Send line and wait for echo
        session.print(line+"\n");

        /* it doesn't match the unicode chars
        session.expect(new String[] { Pattern.quote(line) }, worker);

        *** output 20-Sep-2015::17:14:48.911 ***
        edit 'non-standard ascii characters'

          *** input 20-Sep-2015::17:14:49.555 ***
         edit \746\627\645\746\634\654\750\652\636
        */
        // Wait for prompt or exception
        res = session.expect(plw_prompt, worker);
        if (res.getHit() < 2) {
            // > system global / vdom-admin <disable|enable>
            // You will be logged out for the operation to take effect
            // Do you want to continue? (y/n)n
            //
            // Answer 'y', reconnect and enter global config again
            try {
                session.print("y");
                session.expect("y", worker);
                session.expect(plw_prompt, worker);
            }
            catch (IOException e) {
            }
            catch (SSHSessionException e) {
            }
            if (res.getHit() == 0) {
                LOGGER.error("Reconnecting");
                session.close();
                connection.close();
                connect(worker, mux);
                enterGlobal(worker);
            }
        }

        // Check for error
        reply = res.getText().trim();
        String lines[] = res.getText().split("\n|\r");
        for (int i = 0 ; i < lines.length ; i++) {
            // Ignore 'delete <x>' if entry 'x' does not exist
            if (lines[i].toLowerCase().indexOf("unset oper error ret=1") >= 0)
                return;
            // Ignore 'unset <x>' if entry 'x' does not exist
            if (line.toLowerCase().indexOf("unset ") >= 0 &&
         lines[i].toLowerCase().indexOf("command fail. return code -61") >= 0)
                return;
            // FAIL lines:
            if (lines[i].toLowerCase().indexOf("command fail") >= 0 ||
                lines[i].toLowerCase().indexOf("must be set") >= 0 ||
                lines[i].toLowerCase().indexOf("checkingfail") >= 0 ||
                lines[i].toLowerCase().indexOf("node_check_object fail") >= 0 ||
                lines[i].toLowerCase().indexOf("unknown action") >= 0 ||
                lines[i].toLowerCase().indexOf("operator error") >= 0 ||
                // netsim related
                lines[i].toLowerCase().indexOf("syntax error") >= 0) {
                throw new ApplyException("\n\""+orgline+
                                         "\" ("+line+"): "+reply, true);
            }
        }
    }

    @SuppressWarnings("serial")
    private class ApplyException extends Exception {
        public boolean inConfigMode;

        public ApplyException(String msg, boolean inConfigMode) {
            super(msg);
            this.inConfigMode = inConfigMode;
        }
        public ApplyException(String line, String msg,
                              boolean inConfigMode) {
            super("(command: "+line+"): "+msg);
            this.inConfigMode = inConfigMode;
        }
    }

    @Override
    public void applyConfig(NedWorker worker, int cmd, String data)
        throws NedException, IOException, SSHSessionException {
        String lines[];
        String orgline;
        String path;
        String newpath = "";
        int i, offset;
        int ignoreCmd = 0;
        long lastTime = System.currentTimeMillis();
        long time;
        Stack<String> sk=new Stack<String>();
        List<String> move_after_cfg = new ArrayList<String>();
        List<String> vLinks01 = new ArrayList<String>();

        Map<String,List<String>> insertVdomPolicies =
                new HashMap<String,List<String>>();

        Map<String,List<String>> insertBwl =
                new HashMap<String,List<String>>();

        Map<String,List<String>> insertUrl =
                new HashMap<String,List<String>>();

        List<String> policies = new ArrayList<String>();
        List<String> bwl = new ArrayList<String>();
        List<String> url = new ArrayList<String>();

        String currentVdom = "";
        String currentBwl = "";
        String currentUrl = "";
        String currentSystemInterface = "";
        String currentSecondaryIp = "";

        if (data.equals("")) return;
        LOGGER.info("applyConfig()");

        moveToTopConfig();
        LOGGER.info("Committing");

        // Send config, one line at a time
        try {
            lines = data.split("\n");
            for (i = 0 ; i < lines.length ; i++) {
                // Reset timeout
                time = System.currentTimeMillis();
                if ((time - lastTime) > (0.8 * readTimeout)) {
                    lastTime = time;
                    worker.setTimeout(readTimeout);
                }

                lines[i] = lines[i].trim();
                /*
                 * the real device needs ^v in order to escape the
                 * '?' character
                 */
                lines[i] = lines[i].replaceAll("\\?", "\u0016\\?");
                orgline  = lines[i].trim();
                path     = newpath;

                if(isNetsimDevice) {
                    if (lines[i].indexOf("config ") == 0) {
                        lines[i]  = lines[i].replace("config ", "");
                    }
                    lines[i]  = lines[i].replace("no config ", "no ");
                    if (lines[i].contains("edit ")) {
                        lines[i]  = lines[i].replace("edit ", "edit \"") + "\"";
                    }
                    lines[i]  = lines[i].replace("edit ", "");
                    if (lines[i].equals("!")) {
                        lines[i] = "exit";
                    }
                    print_line_wait(worker, cmd, path, orgline, lines[i], 0);
                    continue;
                }

                //System.err.println("-> line["+i+"]="+lines[i]);
                if (lines[i].indexOf("no config ntpserver") >= 0) continue;
                if (lines[i].indexOf("no config server-list") >= 0) continue;
                if (lines[i].indexOf("no version ") >= 0) continue;
                if (lines[i].indexOf("! first") >= 0) continue;
                if (lines[i].equals("!")) {
                    lines[i] = "end";
                    newpath = path.substring(0, path.lastIndexOf('/'));
                }
                else if (lines[i].equals("exit")) {
                    String value =(String)sk.pop();
                    if (value != null)
                        lines[i] = value;
                    else
                        lines[i] = "next";
                    newpath = path.substring(0, path.lastIndexOf('/'));
                    if (ignoreCmd > 0) {
                        ignoreCmd--;
                        LOGGER.info("Ignoring("+path+") "+lines[i]);
                        if (path.equals("/global/system interface/*") ||
                            path.equals("/system interface/*")) {
                            move_after_cfg.add(lines[i]);
                        }
                        continue;
                    }
                }
                else if ((offset = lines[i].indexOf("config ")) == 0) {
                    if (ignoreCmd > 0)
                        ignoreCmd++;
                    sk.push("end");
                    newpath = path.concat("/" + lines[i].substring(offset + 7));
                }
                else if ((offset = lines[i].indexOf("no edit ")) >= 0) {
                    // Ignore delete of static list entries
                    try {
                        if (isStaticListEntry(path,
                                lines[i].substring(offset + 8))
                                || (isDynamicInterface(worker, path,
                                        lines[i].substring(offset+8), "FROM"))
                                        || (isDynamicVdomProperty(path,
                                                lines[i].substring(offset+8))))
                        {
                            LOGGER.info("Ignoring("+path+") "+lines[i]);
                            continue;
                        }
                        if (isDynamicVdomLinkInterface(path,
                                lines[i].substring(offset+8))) {
                            LOGGER.info("Ignoring("+path+") "+lines[i]);
                            String elem = lines[i].substring(offset+8);
                            String vlink = elem.substring(0, elem.length() - 1);
                            if (vLinks01.contains(vlink)) {
                                print_line_wait(worker, cmd,
                                    "/global/system interface", "", "end", 0);
                                print_line_wait(worker, cmd, "/global",
                                    "", "config system vdom-link", 0);
                                print_line_wait(worker, cmd,
                                    "/global/system vdom-link", "",
                                    "delete "+vlink, 0);
                                print_line_wait(worker, cmd,
                                    "/global/system vdom-link", "", "end", 0);
                                print_line_wait(worker, cmd, "/global",
                                    "", "config system interface", 0);
                            }
                            else {
                                vLinks01.add(vlink);
                            }
                            continue;
                        }

                        /*
                         * workaround for a overlapping 'firewall vip * / extip'
                         * related issue: there cannot exist 2 firewall vip
                         * with the same extip value
                         *
                         */
                        if (path.equals("/vdom/*/firewall vip")) {
                            String poolname = lines[i].substring(offset + 8);
                            String policy = lookUpVipDependantPolicy(worker, currentVdom, poolname);
                            if (!policy.equals("")) {
                                // exit firewall vip mode
                                print_line_wait(worker, cmd, "/vdom/*/firewall vip",
                                        "/vdom/*/firewall vip", "end", 0);

                                // enter firewall policy mode
                                print_line_wait(worker, cmd, "/vdom/*",
                                        "/vdom/*", "config firewall policy", 0);

                                // enter firewall policy mode
                                print_line_wait(worker, cmd, "/vdom/*/firewall policy",
                                        "/vdom/*/firewall policy", "edit "+ policy, 0);

                                /*
                                 *  temporarily set dstaddr to 'all'
                                 */
                                print_line_wait(worker, cmd, "/vdom/*/firewall policy/*",
                                        "/vdom/*/firewall policy/*", "set dstaddr all", 0);

                                // exit firewall policy mode
                                print_line_wait(worker, cmd, "/vdom/*/firewall policy",
                                        "/vdom/*/firewall policy", "end", 0);

                                // go back to firewall vip mode
                                print_line_wait(worker, cmd, "/vdom/*/firewall vip",
                                        "/vdom/*/firewall vip", "config firewall vip", 0);

                            }
                        }

                        /*
                         * workaround for a dependency issue where NSO should
                         * have first issued a 'no' command towards the poolname
                         * before deleting the ippool related entry
                         */
                        if (path.equals("/vdom/*/firewall ippool") ||
                            path.equals("/firewall ippool")) {
                            String poolname = lines[i].substring(offset + 8);
                            String policy = lookUpIppoolDependantPolicy(worker, currentVdom, poolname);
                            String prefix = "";
                            if (path.equals("/vdom/*/firewall ippool")) {
                                prefix = "/vdom/*";
                            }
                            if (!policy.equals("")) {
                                // exit firewall ippool mode
                                print_line_wait(worker, cmd, prefix + "/firewall ippool",
                                        prefix + "/firewall ippool", "end", 0);

                                // enter firewall policy mode
                                print_line_wait(worker, cmd, prefix,
                                        prefix, "config firewall policy", 0);

                                // enter firewall policy mode
                                print_line_wait(worker, cmd, prefix + "/firewall policy",
                                        prefix + "/firewall policy", "edit "+ policy, 0);

                                /*
                                 *  unset ippool which also implies that the
                                 *  poolname is deleted
                                 */
                                print_line_wait(worker, cmd, prefix + "/firewall policy/*",
                                        prefix + "/firewall policy/*", "unset ippool", 0);

                                // exit firewall policy mode
                                print_line_wait(worker, cmd, prefix + "/firewall policy",
                                        prefix + "/firewall policy", "end", 0);

                                // go back to firewall ippool mode
                                print_line_wait(worker, cmd, prefix + "/firewall ippool",
                                        prefix + "/firewall ippool", "config firewall ippool", 0);

                            }
                        }
                    }
                    catch (Exception e) {
                        moveToTopConfig();
                        throw new NedException(e.getMessage());
                    }
                    // quote the content
                    lines[i] = lines[i].substring(0, 8) + "\"" +
                               lines[i].substring(8) + "\"";
                    lines[i] = lines[i].replace("no edit ", "delete ");
                    if (path.equals("/global/system vdom-link") ||
                        path.equals("/system vdom-link")) {
                        LOGGER.info("Ignoring: ("+path+") "+lines[i]);
                        continue;
                    }
                    if (lines[i].indexOf("delete \"mesh.") >= 0 ||
                        lines[i].indexOf("delete \"ssl.") >= 0) {
                        // ignore delete of auto-created static entries:
                        // mesh.<ifname> and ssl.<ifname>
                        LOGGER.info("Ignoring("+path+") "+lines[i]);
                        continue;
                    }
                }
                else if ((offset = lines[i].indexOf("edit ")) >= 0) {
                    String currentEntry = lines[i].substring(lines[i].
                                          indexOf("edit ") + 5);
                    if (path.equals("/vdom")) {
                        currentVdom = currentEntry;
                    }
                    else if (path.equals("/spamfilter bwl") ||
                             path.equals("/vdom/*/spamfilter bwl")) {
                        currentBwl = currentEntry;
                    }
                    else if (path.equals("/webfilter urlfilter") ||
                             path.equals("/vdom/*/webfilter urlfilter")) {
                        currentUrl = currentEntry;
                    }
                    else if (path.equals("/global/system interface") ||
                             path.equals("/system interface")) {
                        currentSystemInterface = currentEntry;
                    }
                    else if (path.equals("/global/system interface/*/secondaryip") ||
                             path.equals("/system interface/*/secondaryip")) {
                        currentSecondaryIp = currentEntry;
                   }
                    if (ignoreCmd > 0)
                        ignoreCmd++;
                    else if (isStaticListEntry(path,
                             lines[i].substring(offset+5))) {

                        // Ignore edit of static list entries (and all contents)
                        ignoreCmd = 1;
                    }
                    else {
                        try {
                            if (isDynamicInterface(worker, path,
                                    lines[i].substring(offset+5), "TO")) {
                                move_after_cfg.add(lines[i]);
                                ignoreCmd = 1;
                            }
                        }
                        catch (Exception e) {
                            moveToTopConfig();
                            throw new NedException(e.getMessage());
                        }
                    }
                    // quote the content
                    lines[i] = lines[i].substring(0, 5) + "\"" +
                               lines[i].substring(5) + "\"";
                    sk.push("next");
                    newpath = path.concat("/*");
                }
                else if (lines[i].indexOf("no ") >= 0) {
                    if (lines[i].indexOf("no service") >= 0) {
                        LOGGER.info("Ignoring("+path+") "+lines[i]);
                        print_line_wait(worker, cmd, path, orgline,
                                        "set service ALL_ICMP", 0);
                        continue;
                    }
                    String tokens[] = lines[i].split(" +");
                    lines[i] = "unset "+tokens[1];
                }
                else if (((lines[i].indexOf("! move ") >= 0) ||
                        (lines[i].indexOf("! insert ") >= 0)) &&
                        (lines[i+1].indexOf("edit ") >= 0)) {
                   if (path.indexOf("identity-based-policy") >= 0) continue;
                   int opStart = lines[i].indexOf("! ") + 2;
                   int opEnd = lines[i].indexOf(" ", opStart);
                   String oper = lines[i].substring(opStart, opEnd);
                   int whereStart = lines[i].indexOf("! "+oper+" ") +
                                    oper.length() + 3;
                   int whereEnd = lines[i].indexOf(" ", whereStart);
                   String where = lines[i].substring(whereStart, whereEnd);
                   String src = lines[i+1].substring(lines[i+1].
                                indexOf("edit ") + 5);
                   String dst = lines[i].substring(lines[i].
                                         indexOf("! "+oper+" "+where)+
                                         oper.length() + where.length() + 4);

                   if (vdom_enabled == 1) {
                       if (path.indexOf("/spamfilter bwl") >= 0) {
                           bwl = insertBwl.get(currentVdom + ";;" + currentBwl);
                           if (bwl == null) {
                               bwl = new ArrayList<String>();
                           }
                           bwl.add("move "+src+" "+where+" "+dst);
                           insertBwl.put(currentVdom + ";;" + currentBwl, bwl);
                       }
                       else if (path.indexOf("/webfilter urlfilter") >= 0) {
                           url = insertUrl.get(currentVdom + ";;" + currentUrl);
                           if (url == null) {
                               url = new ArrayList<String>();
                           }
                           url.add("move "+src+" "+where+" "+dst);
                           insertUrl.put(currentVdom + ";;" + currentUrl, url);
                       }
                       else {
                           policies = insertVdomPolicies.get(currentVdom);
                           if (policies == null) {
                               policies = new ArrayList<String>();
                           }
                           policies.add("move "+src+" "+where+" "+dst);
                           insertVdomPolicies.put(currentVdom, policies);
                       }
                   }
                   else {
                       if (path.indexOf("/spamfilter bwl") >= 0) {
                           bwl = insertBwl.get(currentBwl);
                           if (bwl == null) {
                               bwl = new ArrayList<String>();
                           }
                           bwl.add("move "+src+" "+where+" "+dst);
                           insertBwl.put(currentBwl, bwl);
                       }
                       else if (path.indexOf("/webfilter urlfilter") >= 0) {
                           url = insertUrl.get(currentUrl);
                           if (url == null) {
                               url = new ArrayList<String>();
                           }
                           url.add("move "+src+" "+where+" "+dst);
                           insertUrl.put(currentUrl, url);
                       }
                       else {
                           policies.add("move "+src+" "+where+" "+dst);
                       }
                   }
                   continue;
               }
                else if ((lines[i].indexOf("! move ") >= 0) ||
                        (lines[i].indexOf("! insert ") >= 0)) {
                   continue;
               }
                else {
                    if (lines[i].matches("service(\\s*)\\[ (.*) \\]")) {
                        lines[i] = lines[i].replaceAll("\\[ ", "");
                        lines[i] = lines[i].replaceAll(" \\]", "");
                    }
                    for (String item : Arrays.asList(
                            "comment", "comments", "description", "buffer",
                            "private-key", "certificate")) {
                        if (lines[i].indexOf(item + " ") >= 0) {
                            int begin = lines[i].indexOf(" \"");
                            if (begin >= 0) {
                                String content = lines[i].substring(begin + 1,
                                                 lines[i].length());
                                lines[i] = item + " \"" +
                                        stringDequote(content) + "\"";
                            }
                        }
                    }

                    /*
                     * when configuring back the poolname, ippool must be enable
                     */
                    if (path.equals("/vdom/*/firewall policy/*") ||
                        path.equals("/firewall policy/*")) {
                        String prefix = "";
                        if (lines[i].contains("poolname ")) {
                            if (path.equals("/vdom/*/firewall policy/*")) {
                                prefix = "/vdom/*";
                            }
                            print_line_wait(worker, cmd, prefix + "/firewall policy/*",
                                    prefix + "/firewall policy/*", "set ippool enable", 0);
                        }
                    }

                    /*
                     * handling of an secondaryip overlapping use case
                     */
                    try {
                        handleSecondaryIpOverlapping(worker, cmd, path,
                          currentSystemInterface, currentSecondaryIp, lines[i]);
                    }
                    catch (Exception e) {
                        moveToTopConfig();
                        throw new NedException(e.getMessage());
                    }

                    lines[i] = "set "+lines[i];
                }
                //System.err.println("<- path["+path+"] line["+i+"]="+lines[i]);

                if (ignoreCmd > 0) {
                    // Ignore command
                    LOGGER.info("Ignoring("+path+") "+lines[i]);
                    if (path.equals("/global/system interface/*") ||
                        path.equals("/system interface/*")) {
                        move_after_cfg.add(lines[i]);
                    }
                } else {
                    try {
                        if (removeIdentityBasedPolicy(i, lines)) {
                            handleIdentityBasedPolicyRemoval(worker, cmd, path,
                                    orgline, i, lines);
                        }
                    }
                    catch (Exception e) {
                        moveToTopConfig();
                        throw new NedException(e.getMessage());
                    }
                    // Send command to hardware
                    print_line_wait(worker, cmd, path, orgline, lines[i], 0);
                }
            }
            if (insertVdomPolicies.size() > 0) {
                for (Map.Entry<String, List<String>> entry :
                    insertVdomPolicies.entrySet()) {
                    String key = entry.getKey();
                    List<String> values = entry.getValue();
                    print_line_wait(worker, cmd, "/vdom/*",
                            "/vdom/*", "config vdom", 0);
                    print_line_wait(worker, cmd, "/vdom/*",
                            "/vdom/*", "edit "+key, 0);
                    print_line_wait(worker, cmd, "/vdom/*", "/vdom/*/*",
                            "config firewall policy", 0);

                    for (String value:values) {
                        print_line_wait(worker, cmd, "/vdom/*/*",
                                "/vdom/*/*", value, 0);
                    }
                    print_line_wait(worker, cmd, "/vdom/*/*",
                            "/vdom/*/*", "end", 0);
                    print_line_wait(worker, cmd, "/vdom/*",
                            "/vdom/*", "end", 0);
                }
            }
            else {
                 if (policies.size() > 0) {
                     print_line_wait(worker, cmd, "/firewall policy",
                             "/firewall policy", "config firewall policy", 0);
                     for (String value:policies) {
                         print_line_wait(worker, cmd, "/firewall policy",
                                 "/firewall policy", value, 0);
                     }
                     print_line_wait(worker, cmd, "/firewall policy",
                             "/firewall policy", "end", 0);
                 }
            }

            if (insertBwl.size() > 0) {
                for (Map.Entry<String, List<String>> entry :
                    insertBwl.entrySet()) {
                    String key = entry.getKey();
                    String vdomKey;
                    String bwlKey = key;
                    if (key.contains(";;")) {
                        vdomKey = key.split(";;")[0];
                        bwlKey = key.split(";;")[1];
                        print_line_wait(worker, cmd, "/vdom/*",
                                "/vdom/*", "config vdom", 0);
                        print_line_wait(worker, cmd, "/vdom/*",
                                "/vdom/*", "edit "+vdomKey, 0);
                    }
                    List<String> values = entry.getValue();
                    print_line_wait(worker, cmd, "/spamfilter bwl/*",
                            "/spamfilter bwl/*", "config spamfilter bwl", 0);
                    print_line_wait(worker, cmd, "/spamfilter bwl/*",
                            "/spamfilter bwl/*", "edit "+bwlKey, 0);
                    print_line_wait(worker, cmd, "/spamfilter bwl/*",
                            "/spamfilter bwl/*/*",
                            "config entries", 0);

                    for (String value:values) {
                        print_line_wait(worker, cmd, "/spamfilter bwl/*/*",
                                "/spamfilter bwl/*/*", value, 0);
                    }
                    print_line_wait(worker, cmd, "/spamfilter bwl/*/*",
                            "/spamfilter bwl/*/*", "end", 0);
                    print_line_wait(worker, cmd, "/spamfilter bwl/*",
                            "/spamfilter bwl/*", "end", 0);
                    if (key.contains(";;")) {
                        print_line_wait(worker, cmd, "/vdom/*",
                                "vdom/*", "end", 0);
                    }
                }
            }

            if (insertUrl.size() > 0) {
                for (Map.Entry<String, List<String>> entry :
                    insertUrl.entrySet()) {
                    String key = entry.getKey();
                    String vdomKey;
                    String urlKey = key;
                    if (key.contains(";;")) {
                        vdomKey = key.split(";;")[0];
                        urlKey = key.split(";;")[1];
                        print_line_wait(worker, cmd, "/vdom/*",
                                "/vdom/*", "config vdom", 0);
                        print_line_wait(worker, cmd, "/vdom/*",
                                "/vdom/*", "edit "+vdomKey, 0);
                    }
                    List<String> values = entry.getValue();
                    print_line_wait(worker, cmd, "/webfilter urlfilter/*",
                            "/webfilter urlfilter/*",
                            "config webfilter urlfilter", 0);
                    print_line_wait(worker, cmd, "/webfilter urlfilter/*",
                            "/webfilter urlfilter/*", "edit "+urlKey, 0);
                    print_line_wait(worker, cmd, "/webfilter urlfilter/*",
                            "/webfilter urlfilter/*/*",
                            "config entries", 0);

                    for (String value:values) {
                        print_line_wait(worker, cmd, "/webfilter urlfilter/*/*",
                                "/webfilter urlfilter/*/*", value, 0);
                    }
                    print_line_wait(worker, cmd, "/webfilter urlfilter/*/*",
                            "/webfilter urlfilter/*/*", "end", 0);
                    print_line_wait(worker, cmd, "/webfilter urlfilter/*",
                            "/webfilter urlfilter/*", "end", 0);
                    if (key.contains(";;")) {
                        print_line_wait(worker, cmd, "/vdom/*",
                                "vdom/*", "end", 0);
                    }
                }
            }

            if (move_after_cfg.size() > 0) {
                if (vdom_enabled == 1) {
                    print_line_wait(worker, cmd, "/global/*",
                                    "", "config global", 0);
                }
                print_line_wait(worker, cmd, "/global/system interface",
                    "", "config system interface", 0);
                for (String m : move_after_cfg) {
                    print_line_wait(worker, cmd, "/global/system interface/*",
                    "", m, 0);
                }
                if (vdom_enabled == 1) {
                    print_line_wait(worker, cmd, "/global/system interface/*",
                                    "", "end", 0);
                }
            }
        }
        catch (ApplyException e) {
            moveToTopConfig();
            throw new NedException(e.getMessage());
        }

        // Make sure we exit from all submodes and save config
        LOGGER.info("Commit complete");
        moveToTopConfig();
    }

    private boolean checkSecondaryIpChangeOngoingTransaction(NedWorker worker,
            String fromIp, String path) throws Exception {
        int th = worker.getToTransactionId();
        maapi.attach(th, 0, worker.getUsid());
        try {
            ConfValue toIp = maapi.safeGetElem(th, path);
            if ((toIp != null) && (!toIp.toString().equals(fromIp)))  {
                return true;
            }
        }
        finally {
            maapi.detach(th);
        }
        return false;
    }

    private String lookupOverlappingSecondaryIp(NedWorker worker,
            String interf, String ip) throws Exception {
        maapi.setUserSession(1);
        int th = maapi.startTrans(Conf.DB_RUNNING, Conf.MODE_READ);
        try  {
            NavuList secondaryipList;
            NavuContext context = new NavuContext(maapi, th);
            if (vdom_enabled == 1) {
                secondaryipList = new NavuContainer(context).container(Ncs.hash)
                .container(Ncs._devices_).list(Ncs._device_)
                .elem(new ConfKey(new ConfBuf(device_id))).container(Ncs._config_)
                .container(MODULE, "global").container(MODULE, "system")
                .container(MODULE, "interface")
                .list(MODULE, "interface-list").elem(interf)
                .container(MODULE, "secondaryip").list(MODULE, "secondaryip-list");
            }
            else {
                secondaryipList = new NavuContainer(context).container(Ncs.hash)
               .container(Ncs._devices_).list(Ncs._device_)
               .elem(new ConfKey(new ConfBuf(device_id))).container(Ncs._config_)
               .container(MODULE, "system").container(MODULE, "interface")
               .list(MODULE, "interface-list").elem(interf)
               .container(MODULE, "secondaryip").list(MODULE, "secondaryip-list");
            }
            for (NavuContainer secondaryip : secondaryipList.elements()) {
                ConfValue value = secondaryip.container(MODULE, "ip")
                        .container(MODULE, "ip-mask")
                        .leaf(MODULE, "class_ip").value();
                if ((value != null) && value.toString().equals(ip)) {
                    String overlappedEntry = secondaryip.getKey().toString();
                    overlappedEntry = overlappedEntry.substring(1, overlappedEntry.length() - 1);

                    String ipPath;
                    if (vdom_enabled == 1) {
                        ipPath = new ConfPath("/ncs:devices/device{%s}/"+
                                "config/" + MODULE +
                                ":global/system/interface/interface-list{%s}/"+
                                "secondaryip/secondaryip-list{%s}/ip/ip-mask/class_ip",
                                device_id, interf, overlappedEntry).toString();
                    }
                    else {
                        ipPath = new ConfPath("/ncs:devices/device{%s}/"+
                                "config/" + MODULE +
                                ":system/interface/interface-list{%s}/"+
                                "secondaryip/secondaryip-list{%s}/ip/ip-mask/class_ip",
                                device_id, interf, overlappedEntry).toString();
                    }
                    if (!checkSecondaryIpChangeOngoingTransaction(worker, ip, ipPath)) {
                        return overlappedEntry;
                    }
                }
            }
        }
        catch (Exception e) {
        }
        finally {
            maapi.finishTrans(th);
        }
        return "";
    }


    private void handleSecondaryIpOverlapping(NedWorker worker, int cmd,
            String path, String currentSystemInterface,
            String currentSecondaryIp, String line) throws Exception {
        if ((path.equals("/global/system interface/*/secondaryip/*") ||
             path.equals("/system interface/*/secondaryip/*")) &&
             (line.indexOf("ip ") >= 0)) {
            String overlappedIp = lookupOverlappingSecondaryIp(worker,
                    currentSystemInterface, line.split(" ")[1]);
            if (!overlappedIp.equals("")) {
                String prefix = "";
                if (path.equals("/global/system interface/*/secondaryip/*")) {
                    prefix = "/global";
                }
                print_line_wait(worker, cmd, prefix +
                        "/system interface/*/secondaryip/*",
                        prefix + "/system interface/*/secondaryip/*",
                        "next", 0);

                print_line_wait(worker, cmd, prefix +
                        "/system interface/*/secondaryip",
                        prefix + "/system interface/*/secondaryip",
                        "delete "+ overlappedIp, 0);

                print_line_wait(worker, cmd, prefix +
                        "/system interface/*/secondaryip",
                        prefix + "/system interface/*/secondaryip",
                        "edit "+ currentSecondaryIp, 0);
            }
        }
    }

    private boolean checkPoolnameChange(NedWorker worker, String poolname,
            String path) throws Exception {
        int th = worker.getToTransactionId();
        maapi.attach(th, 0, worker.getUsid());
        try {
            ConfValue newPoolName = maapi.safeGetElem(th, path);
            if ((newPoolName != null) &&
                (!newPoolName.toString().equals(poolname)))  {
                return true;
            }
        }
        finally {
            maapi.detach(th);
        }
        return false;
    }

    private String lookUpIppoolDependantPolicy(NedWorker worker,
            String vdomName, String poolname) throws Exception {
        maapi.setUserSession(1);
        int th = maapi.startTrans(Conf.DB_RUNNING, Conf.MODE_READ);
        try  {
            NavuList policyList;
            NavuContext context = new NavuContext(maapi, th);
            if (vdom_enabled == 1) {
                 policyList = new NavuContainer(context).container(Ncs.hash)
                .container(Ncs._devices_).list(Ncs._device_)
                .elem(new ConfKey(new ConfBuf(device_id))).container(Ncs._config_)
                .container(MODULE, "vdom").list(MODULE, "vdom-list").elem(vdomName)
                .container(MODULE, "firewall").container(MODULE, "policy")
                .list(MODULE, "policy-list");
            }
            else {
                policyList = new NavuContainer(context).container(Ncs.hash)
                .container(Ncs._devices_).list(Ncs._device_)
                .elem(new ConfKey(new ConfBuf(device_id))).container(Ncs._config_)
                .container(MODULE, "firewall").container(MODULE, "policy")
                .list(MODULE, "policy-list");
            }
            for (NavuContainer policy : policyList.elements()) {
                ConfValue value = policy.leaf(MODULE, "poolname").value();
                if ((value != null) && value.toString().equals(poolname)) {
                    String policyName = policy.getKey().toString();
                    policyName = policyName.substring(1, policyName.length() - 1);
                    String poolnamePath;
                    if (vdom_enabled == 1) {
                        poolnamePath = new ConfPath("/ncs:devices/device{%s}/"+
                                "config/" + MODULE +
                                ":vdom/vdom-list{%s}/firewall/policy/policy-list{%s}/poolname",
                                device_id, vdomName, policyName).toString();
                    }
                    else {
                        poolnamePath = new ConfPath("/ncs:devices/device{%s}/"+
                                "config/" + MODULE + ":firewall/policy/policy-list{%s}/poolname",
                                device_id, policyName).toString();
                    }
                    if (checkPoolnameChange(worker, poolname, poolnamePath)) {
                        return policyName;
                    }
                }
            }
        }
        catch (Exception e) {
        }
        finally {
            maapi.finishTrans(th);
        }
        return "";
    }

    private String lookUpVipDependantPolicy(NedWorker worker,
            String vdomName, String vipname) throws Exception {
        maapi.setUserSession(1);
        int th = maapi.startTrans(Conf.DB_RUNNING, Conf.MODE_READ);
        try  {
            NavuContext context = new NavuContext(maapi, th);
            NavuList policyList = new NavuContainer(context).container(Ncs.hash)
                    .container(Ncs._devices_).list(Ncs._device_)
                    .elem(new ConfKey(new ConfBuf(device_id)))
                    .container(Ncs._config_)
                    .container("fortinet-fortios", "vdom")
                    .list("fortinet-fortios", "vdom-list").elem(vdomName)
                    .container("fortinet-fortios", "firewall")
                    .container("fortinet-fortios", "policy")
                    .list("fortinet-fortios", "policy-list");

            for (NavuContainer policy : policyList.elements()) {
                ConfValue value = policy.leaf("fortinet-fortios", "dstaddr").value();
                if ((value != null) && value.toString().equals(vipname)) {
                    String policyName = policy.getKey().toString();
                    policyName = policyName.substring(1, policyName.length() - 1);
                    String vipNamePath = new ConfPath("/ncs:devices/device{%s}/"+
                            "config/fortinet-fortios:vdom/vdom-list{%s}"+
                            "/firewall/policy/policy-list{%s}/dstaddr",
                            device_id, vdomName, policyName).toString();
                    if (checkPoolnameChange(worker, vipname, vipNamePath)) {
                        return policyName;
                    }
                }
            }
        }
        catch (Exception e) {
        }
        finally {
            maapi.finishTrans(th);
        }
        return "";
    }

    private void enterGlobal(NedWorker worker)
        throws IOException, SSHSessionException {

        //System.err.println("enterGlobal()");

        // Enter global config
        if (vdom_enabled == 1) {
            //System.err.println(" > config global");
            session.print("config global\n");
            session.expect("config global", worker);
            session.expect(".*\\(global\\)[ ]#", worker);
        }
    }

    private void enterSystem(NedWorker worker, String path)
        throws Exception {

        //System.err.println("enterSystem(path="+path+")");
        // Config system <path>
        //System.err.println(" > config system "+path);
        session.print("config system "+path+"\n");
        session.expect(".*\\("+path+"\\)[ ]#", worker);
    }

    // mangle output, or just pass through we're invoked during prepare phase
    // of NCS
    public void prepare(NedWorker worker, String data)
        throws Exception {
        session.setTracer(worker);

        LOGGER.info("prepare() config:\n" + data);

        applyConfig(worker, NedCmd.PREPARE_CLI, data);
        worker.prepareResponse();
    }

    public void prepareDry(NedWorker worker, String data)
        throws Exception {

        LOGGER.info("prepareDry() config:\n" + data);

        worker.prepareDryResponse(data);
    }

    // Mangle output, we're invoked during prepare phase of NCS
    public void abort(NedWorker worker, String data)
        throws Exception {
        session.setTracer(worker);

        LOGGER.info("abort()");

        applyConfig(worker, NedCmd.ABORT_CLI, data);
        worker.abortResponse();
    }

    // Mangle output, we're invoked during prepare phase of NCS
    public void revert(NedWorker worker, String data)
        throws Exception {

        LOGGER.info("revert()");
        session.setTracer(worker);

        applyConfig(worker, NedCmd.REVERT_CLI, data);
        worker.revertResponse();
    }

    public void commit(NedWorker worker, int timeout)
        throws Exception {
        session.setTracer(worker);

        // System.err.println("commit()");
        // If not at top, send end to save data and move to top

        moveToTopConfig();
        if (isNetsimDevice) {
            session.println("commit");
            session.expect(".*#", worker);
        }
        worker.commitResponse();
    }

    public void persist(NedWorker worker) throws Exception {
        session.setTracer(worker);

        LOGGER.info("persist()");
        worker.persistResponse();
    }

    public void close(NedWorker worker)
        throws NedException, IOException {
        close();
    }

    public void close() {
        try {
            LOGGER.info("close()");

            if (maapi != null)
                ResourceManager.unregisterResources(this);

            if (session != null) {
                session.setTracer(null);
                session.close();
            }
            if (connection != null)
                connection.close();
        } catch (Exception e) {
        }
    }

    public boolean isAlive() {
        if (session == null) {
            return false;
        }

        return session.serverSideClosed() == false;
    }

    // Calculate checksum of config
    public void getTransId(NedWorker worker)
        throws Exception {
        session.setTracer(worker);
        LOGGER.info("getTransId()");

        String res = "";
        if (isNetsimDevice == false) {
            try {
                LOGGER.info("Waiting " + deviceChecksumDelay +
                            " msecs for the checksum to be calculated...");
                Thread.sleep(deviceChecksumDelay);
            } catch (InterruptedException e) {
                LOGGER.error("sleep interrupted");
            }

            if (vdom_enabled == 1) {
                session.println("config global");
                session.expect("config global", worker);
                session.expect(plw_prompt, worker);
            }
            session.println("get system checksum status");
            session.expect("get system checksum status", worker);
            res = session.expect("^[^#].*#", worker);
            // workaround for the double echo issue
            res = res.replaceAll("get system checksum status\n", "");

            int beginIndex = res.indexOf("all: ") + 5;

            if (beginIndex >= 0) {
                int endIndex = res.indexOf("\n", beginIndex);
                res = res.substring(beginIndex, endIndex);
                LOGGER.info("System checksum: "+res);
                /*
                 *  add global and ha output as they don't affect
                 *  the system checksum
                 */
                for (String s : Arrays.asList("global", "ha")) {
                    session.println("show system " +s );
                    session.expect("show system " + s, worker);
                    res += session.expect("^[^#].*#", worker);
                    // workaround for the double echo issue
                    res = res.replaceAll("show system " + s + "\n", "");
                }

                if (vdom_enabled == 1) {
                    session.println("end");
                    session.expect("end", worker);
                    session.expect(plw_prompt, worker);
                }
            }
            else {
                // Get configuration
                res = getConfig(worker);
            }
        }
        else {
            res = getConfig(worker);
        }

        // debugging log for the double echo issue
        LOGGER.info("Transaction Id Res: "+res);
        trace(worker, "TransactionId Res: " + res, "out");

        // Calculate MD5 checksum
        LOGGER.info("Calculating config checksum");
        byte[] bytes = res.getBytes("UTF-8");
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] thedigest = md.digest(bytes);
        BigInteger md5Number = new BigInteger(1, thedigest);
        String checksum = md5Number.toString(16);
        LOGGER.info("TransId: "+checksum);
        trace(worker, "TransactionId = Checksum:" + checksum, "out");
        worker.getTransIdResponse(checksum);
    }

    public void show(NedWorker worker, String toptag)
        throws Exception {
        session.setTracer(worker);

        if (toptag.equals("global") || toptag.equals("gui")) {
            // Show all config when toptag = 'global'
            LOGGER.info("show()");
            String res = getConfig(worker);
            worker.showCliResponse(res);
        } else {
            // Ignore all other toptags (vdom only)
            worker.showCliResponse("");
        }
    }

    public boolean isConnection(String device_id,
                                InetAddress ip,
                                int port,
                                String proto,  // ssh or telnet
                                String ruser,
                                String pass,
                                String secpass,
                                String keydir,
                                boolean trace,
                                int connectTimeout, // msec
                                int readTimeout,
                                int writeTimeout) {
        return ((this.device_id.equals(device_id)) &&
                (this.ip.equals(ip)) &&
                (this.port == port) &&
                (this.proto.equals(proto)) &&
                (this.ruser.equals(ruser)) &&
                (this.pass.equals(pass)) &&
                (this.secpass.equals(secpass)) &&
                (this.trace == trace) &&
                (this.connectTimeout == connectTimeout) &&
                (this.readTimeout == readTimeout) &&
                (this.writeTimeout == writeTimeout));
    }

    public void command(NedWorker worker, String cmdname, ConfXMLParam[] p)
        throws Exception {
        if (trace)
            session.setTracer(worker);
        NedExpectResult res;
        String cmd  = cmdname;
        String reply = "";

        Pattern[] cmd_prompt = new Pattern[] {
                Pattern.compile("^[^#].* # $"),
                Pattern.compile("Do you want to continue\\? \\(y/n\\)")
        };

        if (trace)
            session.setTracer(worker);

        String path = worker.getCurrentPath().toString();
        LOGGER.info("Cmd name: "+cmdname);
        LOGGER.info("Path: "+path);

        if (!cmdname.equals("system-ha-config")) {
            // Add arguments
            for (int i = 0; i < p.length; ++i) {
                ConfObject val = p[i].getValue();
                if (val != null) {
                    cmd = cmd + " " + val.toString();
                }
            }
        }

        if (isNetsimDevice) {
            // Do nothing.
        }
        else if (vdom_enabled == 1) {
            // global mode
            if (path.contains("/"+MODULE+":global")) {
                session.println("config global");
                session.expect(cmd_prompt, worker);
            }
            // vdom mode
            else {
                if (cmdname.equals("vdom-admin")) {
                    // enter the global one
                    session.println("config global");
                    session.expect(cmd_prompt, worker);
                }
                else {
                    String vdomName = path.substring(path.indexOf("{") + 1,
                            path.indexOf("}"));
                    session.println("config vdom");
                    session.expect(cmd_prompt, worker);
                    session.println("edit "+vdomName);
                    session.expect(cmd_prompt, worker);
                }

            }
        }
        // Send exec command and wait for echo
        trace(worker, "command("+device_id+") - " + cmd, "out");

        if (cmdname.equals("vdom-admin")) {
            if (!isNetsimDevice) {
                session.println("config system global");
                session.expect(cmd_prompt, worker);
                session.println("set " + cmd);
                session.expect(new String[] { Pattern.quote(cmd) }, worker);
                res = session.expect(cmd_prompt, worker);
                reply = "true";
                if (res.getText().contains("Command fail.")) {
                    reply = res.getText();
                }
                session.println("end");
                res = session.expect(cmd_prompt, worker);
                if (res.getHit() == 1) {
                    session.print("y");
                    session.expect("y", worker);
                }

            }
        }
        else if (cmdname.equals("system-ha-config")) {
            if (!isNetsimDevice) {
                session.println("config system ha");
                session.expect("config system ha", worker);
                session.expect(cmd_prompt, worker);

                for (int i = 0; i < p.length; ++i) {
                    ConfObject val = p[i].getValue();
                    if (val != null) {
                        String orgline = p[i].getTag() + " "+val.toString();
                        String line = "set " + orgline;
                        print_line_wait(worker, NedCmd.CMD, path + " " + cmdname, orgline, line, 0);
                    }
                }
                print_line_wait(worker, NedCmd.CMD, path + " " + cmdname, "end", "end", 0);
                reply = "true";
            }
        }
        else {
            // Send CR LF to flush the input in case of read timeout error
            trace(worker, "Sending newline (extra)", "out");

            session.print("\r\n");
            session.expect(cmd_prompt, worker);

            session.println(cmd);
            session.expect(new String[] { Pattern.quote(cmd) }, worker);

            res = session.expect(cmd_prompt, worker);
            if (res.getHit() == 1) {
                session.print("y");
                session.expect("y", worker);
                session.expect(cmd_prompt, worker);
            }

            reply = reply + res.getText();
            if (!isNetsimDevice) {
                session.println("end");
                session.expect(cmd_prompt, worker);
            }
        }
        //Trim potential illegal characters from reply:
        reply = reply.replaceAll("[\u0001-\u0008\u000b\u000c\u000e-\u001f]", "");

        // Report reply
        worker.commandResponse(new ConfXMLParam[] {
                               new ConfXMLParamValue(MODULE, "result",
                               new ConfBuf(reply))});
        return;
    }

    public void showStats(NedWorker worker, int th, ConfPath path)
        throws Exception {

        worker.showStatsResponse(new NedTTL[] {
                new NedTTL(path, 10)
            });
    }

    public void showStatsList(NedWorker worker, int th, ConfPath path)
        throws Exception {

        worker.showStatsListResponse(10, null);
    }

    public NedCliBase newConnection(String device_id,
                                    InetAddress ip,
                                    int port,
                                    String proto,  // ssh or telnet
                                    String ruser,
                                    String pass,
                                    String secpass,
                                    String publicKeyDir,
                                    boolean trace,
                                    int connectTimeout, // msec
                                    int readTimeout,    // msec
                                    int writeTimeout,   // msecs
                                    NedMux mux,
                                    NedWorker worker) {
        FortinetNedCli ned;
        boolean connected;

        LOGGER.info("newConnection()");

        ned = new FortinetNedCli(device_id,
                                  ip, port, proto, ruser, pass, secpass, trace,
                                  connectTimeout, readTimeout, writeTimeout,
                                  mux, worker);

        ned.connect(worker, mux);
        return ned;
    }

    public String toString() {
        return device_id+"-"+ip+":"+Integer.toString(port)+"-"+proto;
    }

    public void trace(NedWorker worker, String msg, String direction) {
        if (trace) {
            worker.trace("-- "+msg+" --\n", direction, device_id);
        }
    }

    @TransCallback(callType=TransCBType.INIT)
    public void init(DpTrans trans) throws DpCallbackException {
        LOGGER.info("init()");
        try {
            if (mm == null) {
                // Need a Maapi socket so that we can attach
                Socket  s = new Socket("127.0.0.1", NcsMain.getInstance().
                                       getNcsPort());
                mm = new Maapi(s);
            }

            mm.attach(trans.getTransaction(),0,trans.getUserInfo().getUserId());

            return;
        }
        catch (Exception e) {
            throw new DpCallbackException("Failed to attach", e);
        }
    }


    @TransCallback(callType=TransCBType.FINISH)
    public void finish(DpTrans trans) throws DpCallbackException {
        LOGGER.info("finish()");
        try {
            mm.detach(trans.getTransaction());
        }
        catch (Exception e) {
            ;
        }
    }

    @DataCallback(callPoint="vdom-hook",
            callType=DataCBType.CREATE)
    public int createVdomSetHook(DpTrans trans, ConfObject[] keyPath)
            throws DpCallbackException {
        try {
            String path = new ConfPath(keyPath).toString();
            LOGGER.info("vdom-hook ==> create(): "+path);
            String deviceId = path.substring(20, path.indexOf("}"));
            String vdom = path.substring(path.indexOf("vdom-list{")+10,
                          path.indexOf("}", path.indexOf("vdom-list{")+10));

            String vdomPropertyPath = new ConfPath("/ncs:devices/device{%s}/"+
                "config/" + MODULE +
                ":global/system/vdom-property/vdom-property-list{%s}",
                deviceId, vdom).toString();

            if (mm.exists(trans.getTransaction(), vdomPropertyPath) == false) {
                try {
                    mm.sharedCreate(trans.getTransaction(), vdomPropertyPath);
                }
                catch (Exception e) {
                    mm.create(trans.getTransaction(), vdomPropertyPath);
                }
            }

            mm.setElem(trans.getTransaction(),
                       "property limits for vdom "+vdom,
                       vdomPropertyPath+"/description");

            dynVdomProps.add(vdom);
            return Conf.REPLY_OK;
        }
        catch (Exception e) {
            throw new DpCallbackException("", e);
        }
    }

    @DataCallback(callPoint="vdom-hook",
            callType=DataCBType.REMOVE)
    public int removeVdomSetHook(DpTrans trans, ConfObject[] keyPath)
            throws DpCallbackException {
        try {
            String path = new ConfPath(keyPath).toString();
            LOGGER.info("vdom-hook ==> remove()"+path);
            String deviceId = path.substring(20, path.indexOf("}"));
            String vdom = path.substring(path.indexOf("vdom-list{")+10,
                          path.indexOf("}", path.indexOf("vdom-list{")+10));

            String vdomPropertyPath = new ConfPath("/ncs:devices/device{%s}/"+
                "config/" + MODULE +
                ":global/system/vdom-property/vdom-property-list{%s}",
                deviceId, vdom).toString();

            dynVdomProps.remove(vdom);

            if (mm.exists(trans.getTransaction(), vdomPropertyPath) == true) {
                mm.delete(trans.getTransaction(), vdomPropertyPath);
            }
            return Conf.REPLY_OK;
        }
        catch (Exception e) {
            throw new DpCallbackException("", e);
        }
    }

    @DataCallback(callPoint="vdom-link-hook",
            callType=DataCBType.CREATE)
    public int createVdomLinkSetHook(DpTrans trans, ConfObject[] keyPath)
            throws DpCallbackException {
        try {
            String path = new ConfPath(keyPath).toString();
            if (path.contains("vdom-link-list")) {
                LOGGER.info("vdom-hook-link ==> create(): "+path);
                String deviceId = path.substring(20, path.indexOf("}"));
                String vdomLink = path.substring(path.indexOf(
                                  "vdom-link-list{")+15,
                                  path.indexOf("}", path.indexOf
                                  ("vdom-link-list{")+15));

                String interfacePath0 = "";
                String interfacePath1 = "";

                // VDOM enabled
                try {
                    interfacePath0 = new ConfPath("/ncs:devices/device{%s}/"+
                        "config/" + MODULE +
                        ":global/system/interface/interface-list{%s0}",
                        deviceId, vdomLink).toString();
                    interfacePath1 = new ConfPath("/ncs:devices/device{%s}/"+
                        "config/" + MODULE +
                        ":global/system/interface/interface-list{%s1}",
                         deviceId, vdomLink).toString();
                }
                // VDOM disabled
                catch (Exception e) {
                    interfacePath0 = new ConfPath("/ncs:devices/device{%s}/"+
                            "config/" + MODULE +
                            ":system/interface/interface-list{%s0}",
                            deviceId, vdomLink).toString();
                    interfacePath1 = new ConfPath("/ncs:devices/device{%s}/"+
                            "config/" + MODULE +
                            ":system/interface/interface-list{%s1}",
                            deviceId, vdomLink).toString();
                }
                int th = trans.getTransaction();


                if (mm.exists(th, interfacePath0) == false) {
                    try {
                        mm.sharedCreate(th, interfacePath0);
                    }
                    catch (Exception e) {
                        mm.create(th, interfacePath0);
                    }
                }

                if (mm.exists(th, interfacePath1) == false) {
                    try {
                        mm.sharedCreate(th, interfacePath1);
                    }
                    catch (Exception e) {
                        mm.create(th, interfacePath1);
                    }
                }

                /*
                 * workaround to duplicate set-hook calls generated by
                 * the service code
                 */

                if (!mm.exists(th, interfacePath0+"/vdom")) {
                    mm.setElem(trans.getTransaction(), "root",
                            interfacePath0+"/vdom");
                }

                if (!mm.exists(th, interfacePath0+"/type")) {
                    mm.setElem(trans.getTransaction(), "vdom-link",
                            interfacePath0+"/type");
                }

                if (!mm.exists(th, interfacePath1+"/vdom")) {
                    mm.setElem(trans.getTransaction(), "root",
                            interfacePath1+"/vdom");
                }

                if (!mm.exists(th, interfacePath1+"/type")) {
                    mm.setElem(trans.getTransaction(), "vdom-link",
                            interfacePath1+"/type");
                }

                dynLinkInterfaces.add(vdomLink+"0");
                dynLinkInterfaces.add(vdomLink+"1");
            }
            return Conf.REPLY_OK;
        }
        catch (Exception e) {
            throw new DpCallbackException("", e);
        }
    }

    @DataCallback(callPoint="vdom-link-hook",
            callType=DataCBType.REMOVE)
    public int removeVdomLinkSetHook(DpTrans trans, ConfObject[] keyPath)
            throws DpCallbackException {
        try {
            String path = new ConfPath(keyPath).toString();
            LOGGER.info("vdom-hook-link ==> remove(): "+path);
            String deviceId = path.substring(20, path.indexOf("}"));
            String vdomLink = path.substring(path.indexOf("vdom-link-list{")+15,
                              path.indexOf("}",
                              path.indexOf("vdom-link-list{")+15));

            String interfacePath0 = "";
            String interfacePath1 = "";

            // VDOM enabled
            try {
                interfacePath0 = new ConfPath("/ncs:devices/device{%s}/"+
                    "config/" + MODULE +
                    ":global/system/interface/interface-list{%s0}",
                    deviceId, vdomLink).toString();
                interfacePath1 = new ConfPath("/ncs:devices/device{%s}/"+
                    "config/" + MODULE +
                    ":global/system/interface/interface-list{%s1}",
                     deviceId, vdomLink).toString();
            }
            catch (Exception e) {
             // VDOM disabled
                interfacePath0 = new ConfPath("/ncs:devices/device{%s}/"+
                        "config/" + MODULE +
                        ":system/interface/interface-list{%s0}",
                        deviceId, vdomLink).toString();
                interfacePath1 = new ConfPath("/ncs:devices/device{%s}/"+
                        "config/" + MODULE +
                        ":system/interface/interface-list{%s1}",
                        deviceId, vdomLink).toString();
            }

            int th = trans.getTransaction();

            dynLinkInterfaces.remove(vdomLink+"0");
            dynLinkInterfaces.remove(vdomLink+"1");

            if (mm.exists(th, interfacePath0) == true) {
                mm.safeDelete(th, interfacePath0);
            }

            if (mm.exists(th, interfacePath1) == true) {
                mm.safeDelete(th, interfacePath1);
            }
            return Conf.REPLY_OK;
        }
        catch (Exception e) {
            throw new DpCallbackException("", e);
        }
    }


    @DataCallback(callPoint="dos-policy-hook",
            callType=DataCBType.CREATE)
    public int createDosPolicySetHook(DpTrans trans, ConfObject[] keyPath)
            throws DpCallbackException {
        final Map<String,String> anomalyMap = new HashMap<String,String>() {{
            put("tcp_syn_flood",    "2000");
            put("tcp_port_scan",    "1000");
            put("tcp_src_session",  "5000");
            put("tcp_dst_session",  "5000");
            put("udp_flood",        "2000");
            put("udp_scan",         "2000");
            put("udp_src_session",  "5000");
            put("udp_dst_session",  "5000");
            put("icmp_flood",       "250");
            put("icmp_sweep",       "100");
            put("icmp_src_session", "300");
            put("icmp_dst_session", "1000");
            put("ip_src_session",   "5000");
            put("ip_dst_session",   "5000");
            put("sctp_flood",       "2000");
            put("sctp_scan",        "1000");
            put("sctp_src_session", "5000");
            put("sctp_dst_session", "5000");
        }};

        try {
            int th = trans.getTransaction();
            String path = new ConfPath(keyPath).toString();
            LOGGER.info("Dos Policy ==> create(): "+path);
            path = path + "/anomaly/entries-list";
            Iterator entries = anomalyMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry entry = (Map.Entry) entries.next();
                String anomalyPath = path +  "{" + entry.getKey() + "}";
                try {
                    mm.sharedCreate(th, anomalyPath);
                }
                catch (Exception e) {
                    mm.create(th, anomalyPath);
                }
                mm.setElem(th, entry.getValue().toString(),
                        anomalyPath + "/threshold");
            }
            return Conf.REPLY_OK;
        }
        catch (Exception e) {
            throw new DpCallbackException("", e);
        }
    }
}
