#!/bin/bash

cat <<EOF
FortiGate-VM64 NETSIM
Virtual domain configuration: enable
EOF
